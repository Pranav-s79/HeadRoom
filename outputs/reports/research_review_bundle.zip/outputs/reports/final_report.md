# ThermalGuard-Cal Final Report

Generated: 2026-06-19T05:19:53+00:00

## Student Summary: What This Run Means

ThermalGuard-Cal builds a 4x4 chip thermal simulator, generates task-placement
datasets, trains point and upper-bound models, calibrates an upper bound with
one-sided conformal prediction, and compares schedulers. The model predicts the
future peak temperature of the whole chip after assigning a task to a candidate
core.

Scheduler categories: simple baselines use randomness or round-robin placement,
sparse-sensor heuristics use only noisy observed temperatures, the oracle uses
privileged true temperatures for reference, and model-based schedulers use
learned future-temperature predictions. ID means the test workload matches the
training/calibration distribution. OOD means the workload is shifted to hotter,
burstier behavior with more sensor dropout. Coverage means the true future peak
temperature is below the predicted upper bound. Selected-core coverage measures
that coverage only after the scheduler has selected one core.

Schedulers with at least one hotspot violation in any evaluated split: coolest_core_observed, trend_aware_observed, random, round_robin, coolest_core_oracle_true_temp, point_prediction_rf, conformal_upper_bound.
Schedulers with zero hotspot violations across all evaluated splits: uncalibrated_quantile.
Conformal status: Coverage improved or was verified on calibration-like data. What is not proven yet: this is not real
silicon validation, and OOD coverage is not guaranteed. The next experiment is
the challenging preset plus multiseed validation, which checks whether scheduler
choice matters in a harder but non-saturating regime.

| Result verdict | Status |
|---|---|
| Pipeline status | working |
| ID calibration | good |
| OOD calibration | bad |
| Sparse-sensor baseline failure | yes |
| Model-based scheduler advantage | promising |
| Conformal advantage over model baselines | mixed |
| Next needed work | challenging preset + multiseed validation |


## Project Summary

ThermalGuard-Cal is a simulation-based Python MVP for conformal upper-bound
thermal scheduling on a 4x4 many-core chip. It implements a stochastic thermal
simulator, stable in-distribution and separate OOD workload generators, sparse
noisy sensors, action-conditioned datasets, point/quantile/conformal models,
scheduler baselines, fair ID/OOD evaluation, plots, and reports.

Current run preset: **challenging**.

## Prediction Target

The model predicts **future peak chip temperature over the horizon** as a
global whole-chip quantity. It does **not** predict the candidate core's own
future temperature in isolation. Therefore selected-core coverage means
coverage of the global outcome that results from a placement choice.

## Simulator And Workloads

The simulator uses heat gain from active task power, ambient cooling,
4-neighbor diffusion, mild thermal inertia, and small stochastic noise. ID
train/calibration/test episodes share the same stable workload distribution.
OOD episodes use a separate higher-power, burstier mix and higher sensor
dropout. Model features only use sparse/noisy sensor observations and workload
metadata; true temperatures are reserved for simulator physics and labels.

The `coolest_core_oracle_true_temp` row is intentionally labeled as a privileged
oracle baseline because it reads true current temperatures. It is useful as a
simulation reference, not as a deployable sparse-sensor scheduler.

## Model Metrics

| split       | model           | metric               |     value |
|:------------|:----------------|:---------------------|----------:|
| calibration | linear_point    | mae                  |  3.34063  |
| calibration | linear_point    | rmse                 |  4.48018  |
| calibration | linear_point    | max_abs_error        | 14.4335   |
| calibration | forest_point    | mae                  |  3.83383  |
| calibration | forest_point    | rmse                 |  5.19242  |
| calibration | forest_point    | max_abs_error        | 20.7087   |
| calibration | quantile_upper  | empirical_coverage   |  0.586934 |
| calibration | quantile_upper  | average_bound        | 54.0974   |
| calibration | quantile_upper  | average_conservatism |  0.434837 |
| calibration | conformal_upper | empirical_coverage   |  0.900206 |
| calibration | conformal_upper | average_bound        | 59.4133   |
| calibration | conformal_upper | average_conservatism |  5.7508   |
| test_id     | linear_point    | mae                  |  3.09849  |
| test_id     | linear_point    | rmse                 |  4.00841  |
| test_id     | linear_point    | max_abs_error        | 13.7133   |
| test_id     | forest_point    | mae                  |  2.58525  |
| test_id     | forest_point    | rmse                 |  3.575    |
| test_id     | forest_point    | max_abs_error        | 13.8763   |
| test_id     | quantile_upper  | empirical_coverage   |  0.710215 |
| test_id     | quantile_upper  | average_bound        | 53.5242   |

## Conformal Calibration Diagnostics

Target coverage, quantile alpha, conformal correction, calibration sample count,
and before/after empirical coverage are reported explicitly below.

| metric                                          | split       |       value |
|:------------------------------------------------|:------------|------------:|
| target_coverage                                 | all         |    0.9      |
| quantile_model_alpha                            | all         |    0.9      |
| conformal_correction                            | calibration |    5.31596  |
| conformal_quantile_level                        | calibration |    0.900206 |
| calibration_samples                             | calibration | 7776        |
| calibration_empirical_coverage_before_conformal | calibration |    0.586934 |
| calibration_empirical_coverage_after_conformal  | calibration |    0.900206 |
| id_empirical_coverage_before_conformal          | test_id     |    0.710215 |
| id_empirical_coverage_after_conformal           | test_id     |    1        |
| ood_empirical_coverage_before_conformal         | test_ood    |    0.496822 |
| ood_empirical_coverage_after_conformal          | test_ood    |    0.650742 |


## ID Scheduler Metrics

| scheduler                     | baseline_type                       |   peak_temperature |   average_max_temperature |   hotspot_violations |   completed_tasks |   assigned_tasks |   marginal_coverage |   selected_core_coverage |   drift_mean_abs_z |   drift_max_ks |
|:------------------------------|:------------------------------------|-------------------:|--------------------------:|---------------------:|------------------:|-----------------:|--------------------:|-------------------------:|-------------------:|---------------:|
| random                        | deployable_baseline_sensor_observed |            72.5221 |                   51.3021 |                    0 |               345 |              476 |                 nan |                      nan |           0.166356 |       0.558184 |
| round_robin                   | deployable_baseline_sensor_observed |            71.9449 |                   49.146  |                    0 |               345 |              476 |                 nan |                      nan |           0.132651 |       0.436396 |
| coolest_core_observed         | deployable_baseline_sensor_observed |           109.702  |                   63.2311 |                  127 |               345 |              476 |                 nan |                      nan |           1.28472  |       0.956662 |
| coolest_core_oracle_true_temp | oracle_privileged_true_temperature  |            67.4588 |                   47.9105 |                    0 |               345 |              476 |                 nan |                      nan |           0.138865 |       0.313561 |
| trend_aware_observed          | deployable_baseline_sensor_observed |           107.974  |                   63.3366 |                  137 |               345 |              476 |                 nan |                      nan |           1.23151  |       0.915638 |
| point_prediction_rf           | model_based_sensor_observed         |            67.5421 |                   46.2    |                    0 |               345 |              476 |                 nan |                      nan |           0.159129 |       0.38933  |
| uncalibrated_quantile         | model_based_sensor_observed         |            72.793  |                   51.5517 |                    0 |               345 |              476 |                 nan |                      nan |           0.341732 |       0.791688 |
| conformal_upper_bound         | model_based_sensor_observed         |            61.5151 |                   45.5844 |                    0 |               345 |              476 |                   1 |                        1 |           0.131943 |       0.437175 |

## OOD Scheduler Metrics

| scheduler                     | baseline_type                       |   peak_temperature |   average_max_temperature |   hotspot_violations |   completed_tasks |   assigned_tasks |   marginal_coverage |   selected_core_coverage |   drift_mean_abs_z |   drift_max_ks |
|:------------------------------|:------------------------------------|-------------------:|--------------------------:|---------------------:|------------------:|-----------------:|--------------------:|-------------------------:|-------------------:|---------------:|
| random                        | deployable_baseline_sensor_observed |           118.587  |                   69.8067 |                  228 |               386 |              590 |          nan        |               nan        |           0.699514 |       0.768892 |
| round_robin                   | deployable_baseline_sensor_observed |            97.2831 |                   61.9796 |                   99 |               386 |              590 |          nan        |               nan        |           0.71074  |       0.768892 |
| coolest_core_observed         | deployable_baseline_sensor_observed |           130      |                   89.5303 |                  412 |               386 |              590 |          nan        |               nan        |           2.38185  |       0.956662 |
| coolest_core_oracle_true_temp | oracle_privileged_true_temperature  |            97.43   |                   60.4271 |                   53 |               386 |              590 |          nan        |               nan        |           0.719662 |       0.768892 |
| trend_aware_observed          | deployable_baseline_sensor_observed |           130      |                   85.7835 |                  384 |               386 |              590 |          nan        |               nan        |           2.18136  |       0.944675 |
| point_prediction_rf           | model_based_sensor_observed         |           124.587  |                   57.5769 |                   57 |               386 |              590 |          nan        |               nan        |           0.725011 |       0.768892 |
| uncalibrated_quantile         | model_based_sensor_observed         |            84.2414 |                   57.2127 |                    0 |               386 |              590 |          nan        |               nan        |           0.735996 |       0.805692 |
| conformal_upper_bound         | model_based_sensor_observed         |            88.1016 |                   56.4084 |                   12 |               386 |              590 |            0.871822 |                 0.871186 |           0.726393 |       0.768892 |

## Coverage Metrics

| split   | scheduler             | coverage_type                             |   nominal_coverage |   empirical_coverage |    n |
|:--------|:----------------------|:------------------------------------------|-------------------:|---------------------:|-----:|
| id      | conformal_upper_bound | marginal_all_candidates_on_visited_states |                0.9 |             1        | 7616 |
| id      | conformal_upper_bound | selected_core_after_scheduler_selection   |                0.9 |             1        |  476 |
| ood     | conformal_upper_bound | marginal_all_candidates_on_visited_states |                0.9 |             0.871822 | 9440 |
| ood     | conformal_upper_bound | selected_core_after_scheduler_selection   |                0.9 |             0.871186 |  590 |

Marginal candidate coverage and selected-core coverage are reported separately.
The difference captures the selection step where the scheduler chooses one
candidate out of 16. Distribution drift is reported separately below and should
not be conflated with the selection-bias coverage gap.

## Does Conformal Add Scheduling Value?

This section compares only `point_prediction_rf`, `uncalibrated_quantile`, and
`conformal_upper_bound`. Conformal should not be called best unless both the
scheduling metrics and coverage metrics support that claim.

| split   | lowest_peak_temperature   | fewest_hotspot_violations   | best_measured_coverage   | conformal_interpretation   |
|:--------|:--------------------------|:----------------------------|:-------------------------|:---------------------------|
| id      | conformal_upper_bound     | point_prediction_rf         | conformal_upper_bound    | safer in this split        |
| ood     | uncalibrated_quantile     | uncalibrated_quantile       | conformal_upper_bound    | not better in this split   |

- For ID, conformal_upper_bound has the lowest peak temperature and point_prediction_rf has the fewest hotspot violations.
- For OOD, uncalibrated_quantile has the lowest peak temperature and uncalibrated_quantile has the fewest hotspot violations.

Calibration can improve statistical trust even when scheduler outcomes are
similar, because it turns an uncalibrated quantile model into an auditable
coverage claim on calibration-like data. It does not create an OOD guarantee.


## Preset Results

This separates saved preset snapshots from the current canonical CSVs, so the
original normal/easy quick result can be compared against a challenging run when
both have been executed.

| result_group   | scheduler                     |   peak_temperature |   average_max_temperature |   hotspot_violations |   completed_tasks |   selected_core_coverage |
|:---------------|:------------------------------|-------------------:|--------------------------:|---------------------:|------------------:|-------------------------:|
| challenging_id | random                        |            72.5221 |                   51.3021 |                    0 |               345 |               nan        |
| challenging_id | round_robin                   |            71.9449 |                   49.146  |                    0 |               345 |               nan        |
| challenging_id | coolest_core_observed         |           109.702  |                   63.2311 |                  127 |               345 |               nan        |
| challenging_id | coolest_core_oracle_true_temp |            67.4588 |                   47.9105 |                    0 |               345 |               nan        |
| challenging_id | trend_aware_observed          |           107.974  |                   63.3366 |                  137 |               345 |               nan        |
| challenging_id | point_prediction_rf           |            67.5421 |                   46.2    |                    0 |               345 |               nan        |
| challenging_id | uncalibrated_quantile         |            72.793  |                   51.5517 |                    0 |               345 |               nan        |
| challenging_id | conformal_upper_bound         |            61.5151 |                   45.5844 |                    0 |               345 |                 1        |
| normal_id      | random                        |            61.9534 |                   45.8285 |                    0 |               231 |               nan        |
| normal_id      | round_robin                   |            52.7977 |                   43.3679 |                    0 |               231 |               nan        |
| normal_id      | coolest_core_observed         |            70.1446 |                   50.3468 |                    0 |               231 |               nan        |
| normal_id      | coolest_core_oracle_true_temp |            52.656  |                   43.0344 |                    0 |               231 |               nan        |
| normal_id      | trend_aware_observed          |            67.0196 |                   49.8475 |                    0 |               231 |               nan        |
| normal_id      | point_prediction_rf           |            48.2876 |                   42.3169 |                    0 |               231 |               nan        |
| normal_id      | uncalibrated_quantile         |            60.4883 |                   47.2592 |                    0 |               231 |               nan        |
| normal_id      | conformal_upper_bound         |            50.5547 |                   42.4335 |                    0 |               231 |                 0.939189 |


## Stress Sweep Result

The sweep uses compact quick-mode settings to screen preset behavior before the
full quick pipeline is rerun with the recommended preset.

## Ranked Candidates

| candidate              | preset      |   score |   baseline_violating_schedulers |   model_peak_std |   model_hotspot_std |   cap_hit_schedulers | all_schedulers_fail   | model_all_identical   | recommended_settings                                                                                                                                                                                                                       |
|:-----------------------|:------------|--------:|--------------------------------:|-----------------:|--------------------:|---------------------:|:----------------------|:----------------------|:-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| challenging            | challenging |      11 |                               2 |          4.54204 |             0       |                    0 | False                 | False                 | heat_gain=0.49; cooling_coeff=0.034; diffusion_coeff=0.045; sensor_dropout_prob=0.06; id_arrival_rate=0.5; id_task_mix=(0.32, 0.42, 0.26); id_burst_probability=0.11; id_burst_extra_rate=1.0; id_power_scale=1.03; id_duration_scale=1.08 |
| challenging_more_burst | challenging |      11 |                               2 |          6.25563 |             0       |                    0 | False                 | False                 | heat_gain=0.49; cooling_coeff=0.034; diffusion_coeff=0.045; sensor_dropout_prob=0.06; id_arrival_rate=0.5; id_task_mix=(0.32, 0.42, 0.26); id_burst_probability=0.11; id_burst_extra_rate=1.0; id_power_scale=1.03; id_duration_scale=1.08 |
| stress                 | stress      |       7 |                               4 |         14.1308  |             2.60875 |                    2 | False                 | False                 | heat_gain=0.66; cooling_coeff=0.026; diffusion_coeff=0.036; sensor_dropout_prob=0.12; id_arrival_rate=0.62; id_task_mix=(0.22, 0.38, 0.4); id_burst_probability=0.12; id_burst_extra_rate=1.2; id_power_scale=1.1; id_duration_scale=1.2   |
| normal                 | normal      |       7 |                               0 |          3.14023 |             0       |                    0 | False                 | False                 |                                                                                                                                                                                                                                            |

## Scheduler Metrics

| candidate              | preset      | split   | scheduler                     |   peak_temperature |   average_max_temperature |   hotspot_violations |   hotspot_timestep_pct |   completed_tasks |   assigned_tasks |   selected_core_coverage |   marginal_coverage | hit_max_temperature_cap   |
|:-----------------------|:------------|:--------|:------------------------------|-------------------:|--------------------------:|---------------------:|-----------------------:|------------------:|-----------------:|-------------------------:|--------------------:|:--------------------------|
| challenging            | challenging | id      | random                        |            64.0341 |                   42.9016 |                    0 |              0         |                30 |               75 |               nan        |          nan        | False                     |
| challenging            | challenging | id      | round_robin                   |            49.7306 |                   39.4123 |                    0 |              0         |                30 |               75 |               nan        |          nan        | False                     |
| challenging            | challenging | id      | coolest_core_observed         |            63.6317 |                   43.7394 |                    0 |              0         |                30 |               75 |               nan        |          nan        | False                     |
| challenging            | challenging | id      | coolest_core_oracle_true_temp |            51.2541 |                   40.0796 |                    0 |              0         |                30 |               75 |               nan        |          nan        | False                     |
| challenging            | challenging | id      | trend_aware_observed          |            62.2808 |                   44.0204 |                    0 |              0         |                30 |               75 |               nan        |          nan        | False                     |
| challenging            | challenging | id      | point_prediction_rf           |            49.1699 |                   39.2426 |                    0 |              0         |                30 |               75 |               nan        |          nan        | False                     |
| challenging            | challenging | id      | uncalibrated_quantile         |            52.1133 |                   43.1991 |                    0 |              0         |                30 |               75 |               nan        |          nan        | False                     |
| challenging            | challenging | id      | conformal_upper_bound         |            46.2739 |                   38.9565 |                    0 |              0         |                30 |               75 |                 1        |            1        | False                     |
| challenging            | challenging | ood     | random                        |            75.065  |                   50.7513 |                    0 |              0         |                40 |              104 |               nan        |          nan        | False                     |
| challenging            | challenging | ood     | round_robin                   |            68.7522 |                   47.3824 |                    0 |              0         |                40 |              104 |               nan        |          nan        | False                     |
| challenging            | challenging | ood     | coolest_core_observed         |            93.3454 |                   58.1571 |                    8 |              0.0571429 |                40 |              104 |               nan        |          nan        | False                     |
| challenging            | challenging | ood     | coolest_core_oracle_true_temp |            61.4923 |                   48.2045 |                    0 |              0         |                40 |              104 |               nan        |          nan        | False                     |
| challenging            | challenging | ood     | trend_aware_observed          |            91.6303 |                   58.5911 |                   10 |              0.0714286 |                40 |              104 |               nan        |          nan        | False                     |
| challenging            | challenging | ood     | point_prediction_rf           |            55.0556 |                   43.1946 |                    0 |              0         |                40 |              104 |               nan        |          nan        | False                     |
| challenging            | challenging | ood     | uncalibrated_quantile         |            59.6971 |                   47.4479 |                    0 |              0         |                40 |              104 |               nan        |          nan        | False                     |
| challenging            | challenging | ood     | conformal_upper_bound         |            56.7686 |                   43.6335 |                    0 |              0         |                40 |              104 |                 0.759615 |            0.766226 | False                     |
| challenging_more_burst | challenging | id      | random                        |            64.0814 |                   42.9704 |                    0 |              0         |                28 |               75 |               nan        |          nan        | False                     |
| challenging_more_burst | challenging | id      | round_robin                   |            49.7815 |                   39.5088 |                    0 |              0         |                28 |               75 |               nan        |          nan        | False                     |
| challenging_more_burst | challenging | id      | coolest_core_observed         |            65.5646 |                   45.1712 |                    0 |              0         |                28 |               75 |               nan        |          nan        | False                     |
| challenging_more_burst | challenging | id      | coolest_core_oracle_true_temp |            50.7332 |                   39.9594 |                    0 |              0         |                28 |               75 |               nan        |          nan        | False                     |
| challenging_more_burst | challenging | id      | trend_aware_observed          |            65.6325 |                   45.1743 |                    0 |              0         |                28 |               75 |               nan        |          nan        | False                     |
| challenging_more_burst | challenging | id      | point_prediction_rf           |            47.284  |                   39.716  |                    0 |              0         |                28 |               75 |               nan        |          nan        | False                     |
| challenging_more_burst | challenging | id      | uncalibrated_quantile         |            52.1448 |                   43.2131 |                    0 |              0         |                28 |               75 |               nan        |          nan        | False                     |
| challenging_more_burst | challenging | id      | conformal_upper_bound         |            47.5133 |                   39.1739 |                    0 |              0         |                28 |               75 |                 1        |            1        | False                     |
| challenging_more_burst | challenging | ood     | random                        |            75.065  |                   50.7513 |                    0 |              0         |                40 |              104 |               nan        |          nan        | False                     |
| challenging_more_burst | challenging | ood     | round_robin                   |            68.7522 |                   47.3824 |                    0 |              0         |                40 |              104 |               nan        |          nan        | False                     |
| challenging_more_burst | challenging | ood     | coolest_core_observed         |            93.3454 |                   58.1571 |                    8 |              0.0571429 |                40 |              104 |               nan        |          nan        | False                     |
| challenging_more_burst | challenging | ood     | coolest_core_oracle_true_temp |            61.4923 |                   48.2045 |                    0 |              0         |                40 |              104 |               nan        |          nan        | False                     |
| challenging_more_burst | challenging | ood     | trend_aware_observed          |            91.6303 |                   58.5911 |                   10 |              0.0714286 |                40 |              104 |               nan        |          nan        | False                     |
| challenging_more_burst | challenging | ood     | point_prediction_rf           |            54.0963 |                   43.6588 |                    0 |              0         |                40 |              104 |               nan        |          nan        | False                     |
| challenging_more_burst | challenging | ood     | uncalibrated_quantile         |            65.6851 |                   48.5945 |                    0 |              0         |                40 |              104 |               nan        |          nan        | False                     |
| challenging_more_burst | challenging | ood     | conformal_upper_bound         |            56.7686 |                   43.6335 |                    0 |              0         |                40 |              104 |                 0.759615 |            0.767428 | False                     |
| normal                 | normal      | id      | random                        |            47.7986 |                   38.0087 |                    0 |              0         |                22 |               46 |               nan        |          nan        | False                     |
| normal                 | normal      | id      | round_robin                   |            44.7799 |                   37.5295 |                    0 |              0         |                22 |               46 |               nan        |          nan        | False                     |
| normal                 | normal      | id      | coolest_core_observed         |            48.4145 |                   38.7598 |                    0 |              0         |                22 |               46 |               nan        |          nan        | False                     |
| normal                 | normal      | id      | coolest_core_oracle_true_temp |            43.168  |                   37.5062 |                    0 |              0         |                22 |               46 |               nan        |          nan        | False                     |
| normal                 | normal      | id      | trend_aware_observed          |            48.0361 |                   38.6314 |                    0 |              0         |                22 |               46 |               nan        |          nan        | False                     |
| normal                 | normal      | id      | point_prediction_rf           |            42.9593 |                   37.424  |                    0 |              0         |                22 |               46 |               nan        |          nan        | False                     |
| normal                 | normal      | id      | uncalibrated_quantile         |            46.4057 |                   39.2242 |                    0 |              0         |                22 |               46 |               nan        |          nan        | False                     |
| normal                 | normal      | id      | conformal_upper_bound         |            43.2676 |                   37.5468 |                    0 |              0         |                22 |               46 |                 0.978261 |            0.976902 | False                     |
| normal                 | normal      | ood     | random                        |            67.1716 |                   47.2636 |                    0 |              0         |                36 |               92 |               nan        |          nan        | False                     |
| normal                 | normal      | ood     | round_robin                   |            55.3096 |                   43.285  |                    0 |              0         |                36 |               92 |               nan        |          nan        | False                     |
| normal                 | normal      | ood     | coolest_core_observed         |            77.5665 |                   53.9677 |                    0 |              0         |                36 |               92 |               nan        |          nan        | False                     |
| normal                 | normal      | ood     | coolest_core_oracle_true_temp |            58.9717 |                   46.1894 |                    0 |              0         |                36 |               92 |               nan        |          nan        | False                     |
| normal                 | normal      | ood     | trend_aware_observed          |            72.9046 |                   52.2623 |                    0 |              0         |                36 |               92 |               nan        |          nan        | False                     |
| normal                 | normal      | ood     | point_prediction_rf           |            49.9454 |                   41.7327 |                    0 |              0         |                36 |               92 |               nan        |          nan        | False                     |
| normal                 | normal      | ood     | uncalibrated_quantile         |            49.5424 |                   42.0351 |                    0 |              0         |                36 |               92 |               nan        |          nan        | False                     |
| normal                 | normal      | ood     | conformal_upper_bound         |            50.6771 |                   42.0679 |                    0 |              0         |                36 |               92 |                 0.478261 |            0.482337 | False                     |
| stress                 | stress      | id      | random                        |            78.5609 |                   47.3906 |                    0 |              0         |                27 |              101 |               nan        |          nan        | False                     |
| stress                 | stress      | id      | round_robin                   |            60.2497 |                   42.9316 |                    0 |              0         |                27 |              101 |               nan        |          nan        | False                     |
| stress                 | stress      | id      | coolest_core_observed         |            88.8759 |                   54.2587 |                    4 |              0.0285714 |                27 |              101 |               nan        |          nan        | False                     |
| stress                 | stress      | id      | coolest_core_oracle_true_temp |            59.0142 |                   43.143  |                    0 |              0         |                27 |              101 |               nan        |          nan        | False                     |
| stress                 | stress      | id      | trend_aware_observed          |            84.7109 |                   52.4036 |                    0 |              0         |                27 |              101 |               nan        |          nan        | False                     |
| stress                 | stress      | id      | point_prediction_rf           |            55.2675 |                   42.9702 |                    0 |              0         |                27 |              101 |               nan        |          nan        | False                     |
| stress                 | stress      | id      | uncalibrated_quantile         |            70.4268 |                   52.4639 |                    0 |              0         |                27 |              101 |               nan        |          nan        | False                     |
| stress                 | stress      | id      | conformal_upper_bound         |            55.6361 |                   42.2978 |                    0 |              0         |                27 |              101 |                 1        |            1        | False                     |
| stress                 | stress      | ood     | random                        |           124.698  |                   65.9341 |                   35 |              0.25      |                25 |              143 |               nan        |          nan        | False                     |
| stress                 | stress      | ood     | round_robin                   |            82.8436 |                   53.4089 |                    0 |              0         |                25 |              143 |               nan        |          nan        | False                     |
| stress                 | stress      | ood     | coolest_core_observed         |           130      |                   77.3781 |                   56 |              0.4       |                25 |              143 |               nan        |          nan        | True                      |
| stress                 | stress      | ood     | coolest_core_oracle_true_temp |            78.1651 |                   56.0858 |                    0 |              0         |                25 |              143 |               nan        |          nan        | False                     |
| stress                 | stress      | ood     | trend_aware_observed          |           130      |                   75.6387 |                   51 |              0.364286  |                25 |              143 |               nan        |          nan        | True                      |
| stress                 | stress      | ood     | point_prediction_rf           |            70.8114 |                   49.4497 |                    0 |              0         |                25 |              143 |               nan        |          nan        | False                     |
| stress                 | stress      | ood     | uncalibrated_quantile         |            97.0275 |                   58.3957 |                    7 |              0.05      |                25 |              143 |               nan        |          nan        | False                     |
| stress                 | stress      | ood     | conformal_upper_bound         |            77.0598 |                   50.1396 |                    0 |              0         |                25 |              143 |                 0.762238 |            0.770542 | False                     |

## Multiseed Result

Seeds: 1, 2, 3, 4, 5

Values are reported as mean +/- sample standard deviation across seeds. Quick
multiseed uses compact per-seed settings so five independent runs complete in a
verification pass; use `run_all.py --quick --preset challenging` for the fuller
single-seed quick result.

| split   | scheduler                     | peak_temperature_mean_std   | average_max_temperature_mean_std   | hotspot_violations_mean_std   | hotspot_timestep_pct_mean_std   | completed_tasks_mean_std   | marginal_coverage_mean_std   | selected_core_coverage_mean_std   | selected_coverage_gap_mean_std   |
|:--------|:------------------------------|:----------------------------|:-----------------------------------|:------------------------------|:--------------------------------|:---------------------------|:-----------------------------|:----------------------------------|:---------------------------------|
| id      | conformal_upper_bound         | 51.292 +/- 0.990            | 42.086 +/- 0.621                   | 0.000 +/- 0.000               | 0.000 +/- 0.000                 | 59.200 +/- 13.198          | 0.986 +/- 0.021              | 0.986 +/- 0.020                   | 0.086 +/- 0.020                  |
| id      | coolest_core_observed         | 79.229 +/- 5.535            | 52.396 +/- 2.725                   | 0.400 +/- 0.894               | 0.002 +/- 0.005                 | 59.200 +/- 13.198          |                              |                                   |                                  |
| id      | coolest_core_oracle_true_temp | 54.922 +/- 1.617            | 43.666 +/- 0.423                   | 0.000 +/- 0.000               | 0.000 +/- 0.000                 | 59.200 +/- 13.198          |                              |                                   |                                  |
| id      | point_prediction_rf           | 51.844 +/- 2.423            | 42.234 +/- 0.695                   | 0.000 +/- 0.000               | 0.000 +/- 0.000                 | 59.200 +/- 13.198          |                              |                                   |                                  |
| id      | random                        | 62.173 +/- 4.396            | 45.799 +/- 1.453                   | 0.000 +/- 0.000               | 0.000 +/- 0.000                 | 59.200 +/- 13.198          |                              |                                   |                                  |
| id      | round_robin                   | 59.764 +/- 6.704            | 44.067 +/- 1.768                   | 0.000 +/- 0.000               | 0.000 +/- 0.000                 | 59.200 +/- 13.198          |                              |                                   |                                  |
| id      | trend_aware_observed          | 75.965 +/- 6.778            | 51.259 +/- 2.348                   | 0.000 +/- 0.000               | 0.000 +/- 0.000                 | 59.200 +/- 13.198          |                              |                                   |                                  |
| id      | uncalibrated_quantile         | 59.723 +/- 3.489            | 47.587 +/- 1.655                   | 0.000 +/- 0.000               | 0.000 +/- 0.000                 | 59.200 +/- 13.198          |                              |                                   |                                  |
| ood     | conformal_upper_bound         | 62.256 +/- 3.477            | 45.926 +/- 1.338                   | 0.000 +/- 0.000               | 0.000 +/- 0.000                 | 60.600 +/- 5.771           | 0.737 +/- 0.098              | 0.735 +/- 0.100                   | -0.165 +/- 0.100                 |
| ood     | coolest_core_observed         | 106.599 +/- 5.206           | 64.046 +/- 2.065                   | 40.000 +/- 11.402             | 0.222 +/- 0.063                 | 60.600 +/- 5.771           |                              |                                   |                                  |
| ood     | coolest_core_oracle_true_temp | 64.863 +/- 4.635            | 48.533 +/- 1.088                   | 0.000 +/- 0.000               | 0.000 +/- 0.000                 | 60.600 +/- 5.771           |                              |                                   |                                  |
| ood     | point_prediction_rf           | 60.412 +/- 2.754            | 45.440 +/- 0.610                   | 0.000 +/- 0.000               | 0.000 +/- 0.000                 | 60.600 +/- 5.771           |                              |                                   |                                  |
| ood     | random                        | 71.758 +/- 2.881            | 51.049 +/- 2.275                   | 0.000 +/- 0.000               | 0.000 +/- 0.000                 | 60.600 +/- 5.771           |                              |                                   |                                  |
| ood     | round_robin                   | 68.535 +/- 1.043            | 47.570 +/- 0.720                   | 0.000 +/- 0.000               | 0.000 +/- 0.000                 | 60.600 +/- 5.771           |                              |                                   |                                  |
| ood     | trend_aware_observed          | 100.444 +/- 4.031           | 61.317 +/- 2.221                   | 30.400 +/- 11.082             | 0.169 +/- 0.062                 | 60.600 +/- 5.771           |                              |                                   |                                  |
| ood     | uncalibrated_quantile         | 66.923 +/- 5.052            | 50.543 +/- 1.646                   | 0.000 +/- 0.000               | 0.000 +/- 0.000                 | 60.600 +/- 5.771           |                              |                                   |                                  |

## Policy-Induced Distribution Drift

Scheduler-level drift summary:

| split   | scheduler                     |   drift_mean_abs_z |   drift_max_ks |
|:--------|:------------------------------|-------------------:|---------------:|
| id      | coolest_core_observed         |           1.28472  |       0.956662 |
| id      | trend_aware_observed          |           1.23151  |       0.915638 |
| id      | uncalibrated_quantile         |           0.341732 |       0.791688 |
| id      | random                        |           0.166356 |       0.558184 |
| id      | point_prediction_rf           |           0.159129 |       0.38933  |
| id      | coolest_core_oracle_true_temp |           0.138865 |       0.313561 |
| id      | round_robin                   |           0.132651 |       0.436396 |
| id      | conformal_upper_bound         |           0.131943 |       0.437175 |
| ood     | coolest_core_observed         |           2.38185  |       0.956662 |
| ood     | trend_aware_observed          |           2.18136  |       0.944675 |
| ood     | uncalibrated_quantile         |           0.735996 |       0.805692 |
| ood     | conformal_upper_bound         |           0.726393 |       0.768892 |
| ood     | point_prediction_rf           |           0.725011 |       0.768892 |
| ood     | coolest_core_oracle_true_temp |           0.719662 |       0.768892 |
| ood     | round_robin                   |           0.71074  |       0.768892 |
| ood     | random                        |           0.699514 |       0.768892 |

Largest feature-level shifts:

| split   | scheduler             | feature               |   calibration_mean |   visited_mean |   abs_mean_z_shift |   ks_stat |
|:--------|:----------------------|:----------------------|-------------------:|---------------:|-------------------:|----------:|
| id      | coolest_core_observed | power_3               |            1.801   |        9.92537 |            6.31769 |  0.77534  |
| id      | trend_aware_observed  | power_3               |            1.801   |        9.1537  |            5.71763 |  0.838365 |
| id      | coolest_core_observed | load_3                |           30.4115  |      159.45    |            4.62371 |  0.703799 |
| id      | trend_aware_observed  | load_3                |           30.4115  |      155.17    |            4.47037 |  0.722706 |
| id      | coolest_core_observed | power_0               |            2.97362 |       10.4236  |            3.86747 |  0.684156 |
| id      | coolest_core_observed | sensor_temp_imputed_3 |           41.0233  |       61.1489  |            3.7402  |  0.63467  |
| id      | trend_aware_observed  | power_0               |            2.97362 |        9.6912  |            3.48728 |  0.67207  |
| id      | trend_aware_observed  | sensor_temp_imputed_3 |           41.0233  |       58.9834  |            3.33776 |  0.614396 |
| id      | coolest_core_observed | load_0                |           51.1276  |      162.053   |            3.16314 |  0.519184 |
| id      | trend_aware_observed  | power_15              |            3.47997 |       10.963   |            3.0867  |  0.59261  |
| id      | trend_aware_observed  | load_15               |           53.6708  |      171.433   |            3.07492 |  0.57238  |
| id      | trend_aware_observed  | load_0                |           51.1276  |      155.737   |            2.98306 |  0.588296 |
| id      | coolest_core_observed | power_12              |            3.40471 |        9.63124 |            2.97718 |  0.668283 |
| id      | coolest_core_observed | load_15               |           53.6708  |      167.345   |            2.96817 |  0.581042 |
| id      | trend_aware_observed  | power_12              |            3.40471 |        9.54358 |            2.93527 |  0.628367 |
| id      | coolest_core_observed | power_15              |            3.47997 |       10.3897  |            2.85022 |  0.64303  |
| id      | coolest_core_observed | load_12               |           59.821   |      154.237   |            2.42338 |  0.567789 |
| id      | coolest_core_observed | sensor_temp_imputed_1 |           43.839   |       60.71    |            2.37488 |  0.551717 |
| id      | coolest_core_observed | sensor_temp_imputed_2 |           43.839   |       60.71    |            2.37488 |  0.551717 |
| id      | coolest_core_observed | sensor_temp_imputed_4 |           43.839   |       60.71    |            2.37488 |  0.551717 |

The drift table compares features visited by each scheduler's rollout against
the calibration feature distribution. This measures policy-induced state
distribution shift even when the workload generator remains in-distribution.

## Figures

Stable figure filenames under `outputs/figures/` (see the Visual Results
section below for plain-English explanations). Regenerate any time with
`python run_make_plots.py`.

- `outputs/figures/executive_summary.png` (portfolio/README overview)
- `outputs/figures/peak_temperature_by_scheduler_id.png`
- `outputs/figures/peak_temperature_by_scheduler_ood.png`
- `outputs/figures/hotspot_violations_id.png`
- `outputs/figures/hotspot_violations_ood.png`
- `outputs/figures/coverage_id_vs_ood.png`
- `outputs/figures/selected_core_coverage_gap.png`
- `outputs/figures/policy_drift_id_vs_ood.png`
- `outputs/figures/safety_vs_throughput_id.png`
- `outputs/figures/safety_vs_throughput_ood.png`
- `outputs/figures/heatmap_conformal_id.png`
- `outputs/figures/heatmap_conformal_ood.png`
- `outputs/figures/heatmap_comparison_ood.png`
- `outputs/figures/max_temperature_by_scheduler.png`

## Visual Results

The figures below turn the raw CSV metrics into the main result story for the
current quick run. All figures live under `outputs/figures/` with stable
filenames and can be regenerated independently with `python run_make_plots.py`.

![Executive summary](../figures/executive_summary.png)

The executive-summary figure is a single portfolio/README overview: OOD peak
temperature by scheduler, OOD hotspot violations, the conformal coverage
collapse from ID to OOD, and conformal policy drift. The detailed per-figure
breakdown follows.

![ID peak temperature by scheduler](../figures/peak_temperature_by_scheduler_id.png)

![OOD peak temperature by scheduler](../figures/peak_temperature_by_scheduler_ood.png)

Peak-temperature comparisons show the thermal safety margin against the 85 C
limit. In this quick run, several model-based schedulers avoid hotspots while
some sparse-observed baselines overheat badly under OOD conditions.

![ID hotspot violations](../figures/hotspot_violations_id.png)

![OOD hotspot violations](../figures/hotspot_violations_ood.png)

Hotspot bars make the safety failures more direct: ID is thermally easy here,
but OOD separates robust policies from brittle observed-sensor heuristics.

![Coverage ID vs OOD](../figures/coverage_id_vs_ood.png)

Conformal coverage is reported three ways: nominal target, marginal candidate
coverage, and selected-core coverage. ID selected coverage is near nominal; OOD
coverage changes under OOD shift. This is why OOD calibration performance should not be
claimed as a formal safety guarantee.

![Selected-core coverage gap](../figures/selected_core_coverage_gap.png)

Selected-core coverage is measured separately because the scheduler chooses one
candidate out of 16. That selection step can create a gap from nominal coverage
even before considering policy-induced state drift.

![Policy drift ID vs OOD](../figures/policy_drift_id_vs_ood.png)

Policy drift compares rollout feature distributions against the calibration
feature distribution. It is a distinct effect from candidate selection bias and
from the deliberate OOD workload shift.

![ID safety vs throughput](../figures/safety_vs_throughput_id.png)

![OOD safety vs throughput](../figures/safety_vs_throughput_ood.png)

The safety/throughput scatter shows whether lower temperature is being bought
with lost completed work. In the current quick run, model-based schedulers avoid
hotspots without losing completed tasks, but harder presets are still needed if
ID remains too thermally easy.

![Conformal ID heatmap](../figures/heatmap_conformal_id.png)

![Conformal OOD heatmap](../figures/heatmap_conformal_ood.png)

![Conformal vs observed-baseline OOD heatmaps](../figures/heatmap_comparison_ood.png)

Representative 4x4 heatmaps show the final recorded chip-temperature frame for
the conformal scheduler. The OOD comparison heatmap puts the conformal scheduler
next to a bad observed-sensor baseline (`coolest_core_observed`), which chases
cool sensor readings into a hotspot under the OOD workload.

### What the figures say in plain English

- **ID calibration holds.** On in-distribution workloads, conformal
  selected-core coverage sits near the 0.9 nominal
  target.
- **OOD calibration breaks.** Under the shifted OOD workload, both marginal and
  selected coverage drop well below nominal, so the conformal guarantee should
  not be claimed as a formal OOD safety guarantee.
- **Selected-core coverage is measured separately** from marginal candidate
  coverage, because the scheduler picks one core out of 16 and that selection
  step can move coverage on its own.
- **Some observed-sensor baselines overheat badly in OOD.** Sparse-sensor
  heuristics such as coolest-core-observed and trend-aware-observed run far past
  the 85 C limit on OOD workloads.
- **Model-based schedulers avoid hotspots in this quick run**, staying under the
  thermal limit without losing completed tasks.
- **This quick run still needs harder presets.** ID is thermally easy here, so a
  more challenging preset is needed to validate that the model-based advantage is
  not just an artifact of an easy in-distribution regime.

## Limitations

This is a research MVP, not a validated chip thermal model. It does not include
HotSpot, OpenROAD, chiplets, DVFS, GNNs, active sensing, FPGA logic, or a web
dashboard. The conformal guarantee is marginal on calibration-like data and is
not a formal OOD safety guarantee.
