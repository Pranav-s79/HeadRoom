# ThermalGuard-Cal Final Report

Generated: 2026-06-20T20:34:33+00:00

## Student Summary: What This Run Means

ThermalGuard-Cal builds a 4x4 chip thermal simulator, generates task-placement
datasets, trains point and upper-bound models, calibrates an upper bound with
one-sided conformal prediction, and compares schedulers. The model predicts the
future peak temperature of the whole chip after assigning a task to a candidate
core.

Scheduler categories: simple baselines use randomness or round-robin placement,
sparse-sensor heuristics use only noisy observed temperatures, the oracle uses
privileged true temperatures for reference, and model-based schedulers use
learned future-temperature predictions. ID means the test workload matches the
training/calibration distribution. OOD means the workload is shifted to hotter,
burstier behavior with more sensor dropout. Coverage means the true future peak
temperature is below the predicted upper bound. Selected-core coverage measures
that coverage only after the scheduler has selected one core.

Schedulers with at least one hotspot violation in any evaluated split: random, coolest_core_observed, coolest_core_oracle_true_temp, trend_aware_observed, uncalibrated_quantile.
Schedulers with zero hotspot violations across all evaluated splits: conformal_upper_bound, point_prediction_rf, round_robin.
Conformal status: Coverage improved or was verified on calibration-like data. What is not proven yet: this is not real
silicon validation, and OOD coverage is not guaranteed. The next experiment is
multiseed validation with the stressed evaluation settings, which checks whether
scheduler choice remains stable across seeds.

| Result verdict | Status |
|---|---|
| Pipeline status | working |
| ID calibration | good |
| OOD calibration | bad |
| Sparse-sensor baseline failure | yes |
| Model-based scheduler advantage | promising |
| Conformal advantage over model baselines | mixed |
| Next needed work | challenging preset + multiseed validation |


## Project Summary

ThermalGuard-Cal is a simulation-based Python MVP for conformal upper-bound
thermal scheduling on a 4x4 many-core chip. It implements a stochastic thermal
simulator, stable in-distribution and separate OOD workload generators, sparse
noisy sensors, action-conditioned datasets, point/quantile/conformal models,
scheduler baselines, fair ID/OOD evaluation, plots, and reports.

Current run preset: **normal**.

Evaluation workload parameters:

| Split | arrival rate | task mix (low, medium, high) | burst probability | burst extra rate | power scale | duration scale |
|---|---:|---|---:|---:|---:|---:|
| ID | 0.38 | (0.45, 0.4, 0.15) | 0 | 0 | 1 | 1 |
| OOD | 0.56 | (0.22, 0.38, 0.4) | 0.12 | 1.4 | 1 | 1 |

## Prediction Target

The model predicts **future peak chip temperature over the horizon** as a
global whole-chip quantity. It does **not** predict the candidate core's own
future temperature in isolation. Therefore selected-core coverage means
coverage of the global outcome that results from a placement choice.

## Simulator And Workloads

The simulator uses heat gain from active task power, ambient cooling,
4-neighbor diffusion, mild thermal inertia, and small stochastic noise. ID
train/calibration/test episodes share the same stable workload distribution.
OOD episodes use a separate higher-power, burstier mix and higher sensor
dropout. Model features only use sparse/noisy sensor observations and workload
metadata; true temperatures are reserved for simulator physics and labels.

The `coolest_core_oracle_true_temp` row is intentionally labeled as a privileged
oracle baseline because it reads true current temperatures. It is useful as a
simulation reference, not as a deployable sparse-sensor scheduler.

## Model Metrics

| split       | model           | metric               |     value |
|:------------|:----------------|:---------------------|----------:|
| calibration | linear_point    | mae                  |  1.40883  |
| calibration | linear_point    | rmse                 |  1.81594  |
| calibration | linear_point    | max_abs_error        |  6.36418  |
| calibration | forest_point    | mae                  |  1.50509  |
| calibration | forest_point    | rmse                 |  2.01692  |
| calibration | forest_point    | max_abs_error        |  5.71032  |
| calibration | quantile_upper  | empirical_coverage   |  0.961928 |
| calibration | quantile_upper  | average_bound        | 45.6744   |
| calibration | quantile_upper  | average_conservatism |  2.33225  |
| calibration | conformal_upper | empirical_coverage   |  0.961928 |
| calibration | conformal_upper | average_bound        | 45.6744   |
| calibration | conformal_upper | average_conservatism |  2.33225  |
| test_id     | linear_point    | mae                  |  2.21006  |
| test_id     | linear_point    | rmse                 |  3.01349  |
| test_id     | linear_point    | max_abs_error        |  8.3904   |
| test_id     | forest_point    | mae                  |  2.47282  |
| test_id     | forest_point    | rmse                 |  3.12795  |
| test_id     | forest_point    | max_abs_error        |  9.53718  |
| test_id     | quantile_upper  | empirical_coverage   |  0.602273 |
| test_id     | quantile_upper  | average_bound        | 45.626    |

## Conformal Calibration Diagnostics

Target coverage, quantile alpha, conformal correction, calibration sample count,
and before/after empirical coverage are reported explicitly below.

| metric                                          | split       |       value |
|:------------------------------------------------|:------------|------------:|
| target_coverage                                 | all         |    0.9      |
| quantile_model_alpha                            | all         |    0.9      |
| conformal_correction                            | calibration |    0        |
| conformal_quantile_level                        | calibration |    0.900308 |
| calibration_samples                             | calibration | 4544        |
| calibration_empirical_coverage_before_conformal | calibration |    0.961928 |
| calibration_empirical_coverage_after_conformal  | calibration |    0.961928 |
| id_empirical_coverage_before_conformal          | test_id     |    0.602273 |
| id_empirical_coverage_after_conformal           | test_id     |    0.602273 |
| ood_empirical_coverage_before_conformal         | test_ood    |    0.305949 |
| ood_empirical_coverage_after_conformal          | test_ood    |    0.305949 |

In this run, the quantile model was already conservative on the calibration split, so conformal calibration verified the bound but did not widen it.


## Bound Conservatism Audit

Positive values mean the calibrated upper bound is above the true realized
future peak. Large positive values mean the bound is conservative and may be too
loose to strongly differentiate candidate cores.

| quantity                                                                        |   average_c |
|:--------------------------------------------------------------------------------|------------:|
| ID test conformal upper - true outcome, all saved test predictions              |    0.518057 |
| ID rollout conformal upper - realized outcome, all candidates on visited states |    2.367    |
| ID rollout conformal upper - realized outcome, selected scheduler core          |    2.37706  |
| ID selected average conformal upper                                             |   46.0158   |
| ID selected average realized outcome                                            |   43.6387   |


## ID Scheduler Metrics

| scheduler                     | baseline_type                       |   peak_temperature |   average_max_temperature |   hotspot_violations |   completed_tasks |   assigned_tasks |   marginal_coverage |   selected_core_coverage |   average_selected_conservatism |   drift_mean_abs_z |   drift_max_ks |
|:------------------------------|:------------------------------------|-------------------:|--------------------------:|---------------------:|------------------:|-----------------:|--------------------:|-------------------------:|--------------------------------:|-------------------:|---------------:|
| random                        | deployable_baseline_sensor_observed |            52.1919 |                   45.3804 |                    0 |               247 |              297 |          nan        |               nan        |                       nan       |           0.189316 |       0.446353 |
| round_robin                   | deployable_baseline_sensor_observed |            55.9879 |                   44.3059 |                    0 |               247 |              297 |          nan        |               nan        |                       nan       |           0.134896 |       0.451961 |
| coolest_core_observed         | deployable_baseline_sensor_observed |            67.0557 |                   50.1485 |                    0 |               247 |              297 |          nan        |               nan        |                       nan       |           1.16624  |       0.897227 |
| coolest_core_oracle_true_temp | oracle_privileged_true_temperature  |            51.4955 |                   43.6811 |                    0 |               247 |              297 |          nan        |               nan        |                       nan       |           0.138074 |       0.353535 |
| trend_aware_observed          | deployable_baseline_sensor_observed |            69.6589 |                   49.4223 |                    0 |               247 |              297 |          nan        |               nan        |                       nan       |           1.11266  |       0.836621 |
| point_prediction_rf           | model_based_sensor_observed         |            49.4724 |                   43.0857 |                    0 |               247 |              297 |          nan        |               nan        |                       nan       |           0.151012 |       0.377389 |
| uncalibrated_quantile         | model_based_sensor_observed         |            55.7334 |                   45.5594 |                    0 |               247 |              297 |          nan        |               nan        |                       nan       |           0.56121  |       0.760563 |
| conformal_upper_bound         | model_based_sensor_observed         |            51.4536 |                   43.0724 |                    0 |               247 |              297 |            0.875421 |                 0.878788 |                         2.37706 |           0.259571 |       0.544632 |

## OOD Scheduler Metrics

| scheduler                     | baseline_type                       |   peak_temperature |   average_max_temperature |   hotspot_violations |   completed_tasks |   assigned_tasks |   marginal_coverage |   selected_core_coverage |   average_selected_conservatism |   drift_mean_abs_z |   drift_max_ks |
|:------------------------------|:------------------------------------|-------------------:|--------------------------:|---------------------:|------------------:|-----------------:|--------------------:|-------------------------:|--------------------------------:|-------------------:|---------------:|
| random                        | deployable_baseline_sensor_observed |            97.0733 |                   58.205  |                   59 |               327 |              477 |          nan        |               nan        |                       nan       |            1.46476 |       0.822393 |
| round_robin                   | deployable_baseline_sensor_observed |            80.0458 |                   53.4916 |                    0 |               327 |              477 |          nan        |               nan        |                       nan       |            1.44101 |       0.822393 |
| coolest_core_observed         | deployable_baseline_sensor_observed |           130      |                   75.9608 |                  296 |               327 |              477 |          nan        |               nan        |                       nan       |            3.58529 |       0.943396 |
| coolest_core_oracle_true_temp | oracle_privileged_true_temperature  |            85.334  |                   52.2269 |                    2 |               327 |              477 |          nan        |               nan        |                       nan       |            1.41841 |       0.822393 |
| trend_aware_observed          | deployable_baseline_sensor_observed |           125.201  |                   72.0412 |                  257 |               327 |              477 |          nan        |               nan        |                       nan       |            3.33969 |       0.928721 |
| point_prediction_rf           | model_based_sensor_observed         |            72.6787 |                   49.9069 |                    0 |               327 |              477 |          nan        |               nan        |                       nan       |            1.42069 |       0.838574 |
| uncalibrated_quantile         | model_based_sensor_observed         |            90.127  |                   51.3333 |                    9 |               327 |              477 |          nan        |               nan        |                       nan       |            1.40127 |       0.844701 |
| conformal_upper_bound         | model_based_sensor_observed         |            70.0535 |                   49.668  |                    0 |               327 |              477 |            0.522275 |                 0.519916 |                        -2.52407 |            1.44231 |       0.84696  |

## Coverage Metrics

| split   | scheduler             | coverage_type                             |   nominal_coverage |   empirical_coverage |    n |   bound_violations |   average_bound |   average_actual |   average_conservatism |
|:--------|:----------------------|:------------------------------------------|-------------------:|---------------------:|-----:|-------------------:|----------------:|-----------------:|-----------------------:|
| id      | conformal_upper_bound | marginal_all_candidates_on_visited_states |                0.9 |             0.875421 | 4752 |                592 |         46.0406 |          43.6736 |                2.367   |
| id      | conformal_upper_bound | selected_core_after_scheduler_selection   |                0.9 |             0.878788 |  297 |                 36 |         46.0158 |          43.6387 |                2.37706 |
| ood     | conformal_upper_bound | marginal_all_candidates_on_visited_states |                0.9 |             0.522275 | 7632 |               3646 |         49.307  |          51.7786 |               -2.47157 |
| ood     | conformal_upper_bound | selected_core_after_scheduler_selection   |                0.9 |             0.519916 |  477 |                229 |         49.1995 |          51.7235 |               -2.52407 |

Marginal candidate coverage and selected-core coverage are reported separately.
The difference captures the selection step where the scheduler chooses one
candidate out of 16. Distribution drift is reported separately below and should
not be conflated with the selection-bias coverage gap.

## Does Conformal Add Scheduling Value?

This section compares only `point_prediction_rf`, `uncalibrated_quantile`, and
`conformal_upper_bound`. Conformal should not be called best unless both the
scheduling metrics and coverage metrics support that claim.

| split   | lowest_peak_temperature   | fewest_hotspot_violations   | best_measured_coverage   | conformal_interpretation               |
|:--------|:--------------------------|:----------------------------|:-------------------------|:---------------------------------------|
| id      | point_prediction_rf       | point_prediction_rf         | conformal_upper_bound    | coverage value, similar safety outcome |
| ood     | conformal_upper_bound     | point_prediction_rf         | conformal_upper_bound    | safer in this split                    |

- For ID, point_prediction_rf has the lowest peak temperature and point_prediction_rf has the fewest hotspot violations.
- For OOD, conformal_upper_bound has the lowest peak temperature and point_prediction_rf has the fewest hotspot violations.

Calibration can improve statistical trust even when scheduler outcomes are
similar, because it turns an uncalibrated quantile model into an auditable
coverage claim on calibration-like data. It does not create an OOD guarantee.


## Preset Results

This separates saved preset snapshots from the current canonical CSVs, so the
original normal/easy quick result can be compared against a challenging run when
both have been executed.

| result_group   | scheduler                     |   peak_temperature |   average_max_temperature |   hotspot_violations |   completed_tasks |   selected_core_coverage |
|:---------------|:------------------------------|-------------------:|--------------------------:|---------------------:|------------------:|-------------------------:|
| normal_id      | random                        |            52.1919 |                   45.3804 |                    0 |               247 |               nan        |
| normal_id      | round_robin                   |            55.9879 |                   44.3059 |                    0 |               247 |               nan        |
| normal_id      | coolest_core_observed         |            67.0557 |                   50.1485 |                    0 |               247 |               nan        |
| normal_id      | coolest_core_oracle_true_temp |            51.4955 |                   43.6811 |                    0 |               247 |               nan        |
| normal_id      | trend_aware_observed          |            69.6589 |                   49.4223 |                    0 |               247 |               nan        |
| normal_id      | point_prediction_rf           |            49.4724 |                   43.0857 |                    0 |               247 |               nan        |
| normal_id      | uncalibrated_quantile         |            55.7334 |                   45.5594 |                    0 |               247 |               nan        |
| normal_id      | conformal_upper_bound         |            51.4536 |                   43.0724 |                    0 |               247 |                 0.878788 |


## Stress Sweep Result

The sweep uses compact quick-mode settings to screen preset behavior before the
full quick pipeline is rerun with the recommended preset.

## Ranked Candidates

| candidate              | preset      |   score |   baseline_violating_schedulers |   model_peak_std |   model_hotspot_std |   cap_hit_schedulers | all_schedulers_fail   | model_all_identical   | recommended_settings                                                                                                                                                                                                                       |
|:-----------------------|:------------|--------:|--------------------------------:|-----------------:|--------------------:|---------------------:|:----------------------|:----------------------|:-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| challenging            | challenging |      11 |                               2 |          4.54204 |             0       |                    0 | False                 | False                 | heat_gain=0.49; cooling_coeff=0.034; diffusion_coeff=0.045; sensor_dropout_prob=0.06; id_arrival_rate=0.5; id_task_mix=(0.32, 0.42, 0.26); id_burst_probability=0.11; id_burst_extra_rate=1.0; id_power_scale=1.03; id_duration_scale=1.08 |
| challenging_more_burst | challenging |      11 |                               2 |          6.25563 |             0       |                    0 | False                 | False                 | heat_gain=0.49; cooling_coeff=0.034; diffusion_coeff=0.045; sensor_dropout_prob=0.06; id_arrival_rate=0.5; id_task_mix=(0.32, 0.42, 0.26); id_burst_probability=0.11; id_burst_extra_rate=1.0; id_power_scale=1.03; id_duration_scale=1.08 |
| stress                 | stress      |       7 |                               4 |         14.1308  |             2.60875 |                    2 | False                 | False                 | heat_gain=0.66; cooling_coeff=0.026; diffusion_coeff=0.036; sensor_dropout_prob=0.12; id_arrival_rate=0.62; id_task_mix=(0.22, 0.38, 0.4); id_burst_probability=0.12; id_burst_extra_rate=1.2; id_power_scale=1.1; id_duration_scale=1.2   |
| normal                 | normal      |       7 |                               0 |          3.14023 |             0       |                    0 | False                 | False                 |                                                                                                                                                                                                                                            |

## Scheduler Metrics

| candidate              | preset      | split   | scheduler                     |   peak_temperature |   average_max_temperature |   hotspot_violations |   hotspot_timestep_pct |   completed_tasks |   assigned_tasks |   selected_core_coverage |   marginal_coverage | hit_max_temperature_cap   |
|:-----------------------|:------------|:--------|:------------------------------|-------------------:|--------------------------:|---------------------:|-----------------------:|------------------:|-----------------:|-------------------------:|--------------------:|:--------------------------|
| challenging            | challenging | id      | random                        |            64.0341 |                   42.9016 |                    0 |              0         |                30 |               75 |               nan        |          nan        | False                     |
| challenging            | challenging | id      | round_robin                   |            49.7306 |                   39.4123 |                    0 |              0         |                30 |               75 |               nan        |          nan        | False                     |
| challenging            | challenging | id      | coolest_core_observed         |            63.6317 |                   43.7394 |                    0 |              0         |                30 |               75 |               nan        |          nan        | False                     |
| challenging            | challenging | id      | coolest_core_oracle_true_temp |            51.2541 |                   40.0796 |                    0 |              0         |                30 |               75 |               nan        |          nan        | False                     |
| challenging            | challenging | id      | trend_aware_observed          |            62.2808 |                   44.0204 |                    0 |              0         |                30 |               75 |               nan        |          nan        | False                     |
| challenging            | challenging | id      | point_prediction_rf           |            49.1699 |                   39.2426 |                    0 |              0         |                30 |               75 |               nan        |          nan        | False                     |
| challenging            | challenging | id      | uncalibrated_quantile         |            52.1133 |                   43.1991 |                    0 |              0         |                30 |               75 |               nan        |          nan        | False                     |
| challenging            | challenging | id      | conformal_upper_bound         |            46.2739 |                   38.9565 |                    0 |              0         |                30 |               75 |                 1        |            1        | False                     |
| challenging            | challenging | ood     | random                        |            75.065  |                   50.7513 |                    0 |              0         |                40 |              104 |               nan        |          nan        | False                     |
| challenging            | challenging | ood     | round_robin                   |            68.7522 |                   47.3824 |                    0 |              0         |                40 |              104 |               nan        |          nan        | False                     |
| challenging            | challenging | ood     | coolest_core_observed         |            93.3454 |                   58.1571 |                    8 |              0.0571429 |                40 |              104 |               nan        |          nan        | False                     |
| challenging            | challenging | ood     | coolest_core_oracle_true_temp |            61.4923 |                   48.2045 |                    0 |              0         |                40 |              104 |               nan        |          nan        | False                     |
| challenging            | challenging | ood     | trend_aware_observed          |            91.6303 |                   58.5911 |                   10 |              0.0714286 |                40 |              104 |               nan        |          nan        | False                     |
| challenging            | challenging | ood     | point_prediction_rf           |            55.0556 |                   43.1946 |                    0 |              0         |                40 |              104 |               nan        |          nan        | False                     |
| challenging            | challenging | ood     | uncalibrated_quantile         |            59.6971 |                   47.4479 |                    0 |              0         |                40 |              104 |               nan        |          nan        | False                     |
| challenging            | challenging | ood     | conformal_upper_bound         |            56.7686 |                   43.6335 |                    0 |              0         |                40 |              104 |                 0.759615 |            0.766226 | False                     |
| challenging_more_burst | challenging | id      | random                        |            64.0814 |                   42.9704 |                    0 |              0         |                28 |               75 |               nan        |          nan        | False                     |
| challenging_more_burst | challenging | id      | round_robin                   |            49.7815 |                   39.5088 |                    0 |              0         |                28 |               75 |               nan        |          nan        | False                     |
| challenging_more_burst | challenging | id      | coolest_core_observed         |            65.5646 |                   45.1712 |                    0 |              0         |                28 |               75 |               nan        |          nan        | False                     |
| challenging_more_burst | challenging | id      | coolest_core_oracle_true_temp |            50.7332 |                   39.9594 |                    0 |              0         |                28 |               75 |               nan        |          nan        | False                     |
| challenging_more_burst | challenging | id      | trend_aware_observed          |            65.6325 |                   45.1743 |                    0 |              0         |                28 |               75 |               nan        |          nan        | False                     |
| challenging_more_burst | challenging | id      | point_prediction_rf           |            47.284  |                   39.716  |                    0 |              0         |                28 |               75 |               nan        |          nan        | False                     |
| challenging_more_burst | challenging | id      | uncalibrated_quantile         |            52.1448 |                   43.2131 |                    0 |              0         |                28 |               75 |               nan        |          nan        | False                     |
| challenging_more_burst | challenging | id      | conformal_upper_bound         |            47.5133 |                   39.1739 |                    0 |              0         |                28 |               75 |                 1        |            1        | False                     |
| challenging_more_burst | challenging | ood     | random                        |            75.065  |                   50.7513 |                    0 |              0         |                40 |              104 |               nan        |          nan        | False                     |
| challenging_more_burst | challenging | ood     | round_robin                   |            68.7522 |                   47.3824 |                    0 |              0         |                40 |              104 |               nan        |          nan        | False                     |
| challenging_more_burst | challenging | ood     | coolest_core_observed         |            93.3454 |                   58.1571 |                    8 |              0.0571429 |                40 |              104 |               nan        |          nan        | False                     |
| challenging_more_burst | challenging | ood     | coolest_core_oracle_true_temp |            61.4923 |                   48.2045 |                    0 |              0         |                40 |              104 |               nan        |          nan        | False                     |
| challenging_more_burst | challenging | ood     | trend_aware_observed          |            91.6303 |                   58.5911 |                   10 |              0.0714286 |                40 |              104 |               nan        |          nan        | False                     |
| challenging_more_burst | challenging | ood     | point_prediction_rf           |            54.0963 |                   43.6588 |                    0 |              0         |                40 |              104 |               nan        |          nan        | False                     |
| challenging_more_burst | challenging | ood     | uncalibrated_quantile         |            65.6851 |                   48.5945 |                    0 |              0         |                40 |              104 |               nan        |          nan        | False                     |
| challenging_more_burst | challenging | ood     | conformal_upper_bound         |            56.7686 |                   43.6335 |                    0 |              0         |                40 |              104 |                 0.759615 |            0.767428 | False                     |
| normal                 | normal      | id      | random                        |            47.7986 |                   38.0087 |                    0 |              0         |                22 |               46 |               nan        |          nan        | False                     |
| normal                 | normal      | id      | round_robin                   |            44.7799 |                   37.5295 |                    0 |              0         |                22 |               46 |               nan        |          nan        | False                     |
| normal                 | normal      | id      | coolest_core_observed         |            48.4145 |                   38.7598 |                    0 |              0         |                22 |               46 |               nan        |          nan        | False                     |
| normal                 | normal      | id      | coolest_core_oracle_true_temp |            43.168  |                   37.5062 |                    0 |              0         |                22 |               46 |               nan        |          nan        | False                     |
| normal                 | normal      | id      | trend_aware_observed          |            48.0361 |                   38.6314 |                    0 |              0         |                22 |               46 |               nan        |          nan        | False                     |
| normal                 | normal      | id      | point_prediction_rf           |            42.9593 |                   37.424  |                    0 |              0         |                22 |               46 |               nan        |          nan        | False                     |
| normal                 | normal      | id      | uncalibrated_quantile         |            46.4057 |                   39.2242 |                    0 |              0         |                22 |               46 |               nan        |          nan        | False                     |
| normal                 | normal      | id      | conformal_upper_bound         |            43.2676 |                   37.5468 |                    0 |              0         |                22 |               46 |                 0.978261 |            0.976902 | False                     |
| normal                 | normal      | ood     | random                        |            67.1716 |                   47.2636 |                    0 |              0         |                36 |               92 |               nan        |          nan        | False                     |
| normal                 | normal      | ood     | round_robin                   |            55.3096 |                   43.285  |                    0 |              0         |                36 |               92 |               nan        |          nan        | False                     |
| normal                 | normal      | ood     | coolest_core_observed         |            77.5665 |                   53.9677 |                    0 |              0         |                36 |               92 |               nan        |          nan        | False                     |
| normal                 | normal      | ood     | coolest_core_oracle_true_temp |            58.9717 |                   46.1894 |                    0 |              0         |                36 |               92 |               nan        |          nan        | False                     |
| normal                 | normal      | ood     | trend_aware_observed          |            72.9046 |                   52.2623 |                    0 |              0         |                36 |               92 |               nan        |          nan        | False                     |
| normal                 | normal      | ood     | point_prediction_rf           |            49.9454 |                   41.7327 |                    0 |              0         |                36 |               92 |               nan        |          nan        | False                     |
| normal                 | normal      | ood     | uncalibrated_quantile         |            49.5424 |                   42.0351 |                    0 |              0         |                36 |               92 |               nan        |          nan        | False                     |
| normal                 | normal      | ood     | conformal_upper_bound         |            50.6771 |                   42.0679 |                    0 |              0         |                36 |               92 |                 0.478261 |            0.482337 | False                     |
| stress                 | stress      | id      | random                        |            78.5609 |                   47.3906 |                    0 |              0         |                27 |              101 |               nan        |          nan        | False                     |
| stress                 | stress      | id      | round_robin                   |            60.2497 |                   42.9316 |                    0 |              0         |                27 |              101 |               nan        |          nan        | False                     |
| stress                 | stress      | id      | coolest_core_observed         |            88.8759 |                   54.2587 |                    4 |              0.0285714 |                27 |              101 |               nan        |          nan        | False                     |
| stress                 | stress      | id      | coolest_core_oracle_true_temp |            59.0142 |                   43.143  |                    0 |              0         |                27 |              101 |               nan        |          nan        | False                     |
| stress                 | stress      | id      | trend_aware_observed          |            84.7109 |                   52.4036 |                    0 |              0         |                27 |              101 |               nan        |          nan        | False                     |
| stress                 | stress      | id      | point_prediction_rf           |            55.2675 |                   42.9702 |                    0 |              0         |                27 |              101 |               nan        |          nan        | False                     |
| stress                 | stress      | id      | uncalibrated_quantile         |            70.4268 |                   52.4639 |                    0 |              0         |                27 |              101 |               nan        |          nan        | False                     |
| stress                 | stress      | id      | conformal_upper_bound         |            55.6361 |                   42.2978 |                    0 |              0         |                27 |              101 |                 1        |            1        | False                     |
| stress                 | stress      | ood     | random                        |           124.698  |                   65.9341 |                   35 |              0.25      |                25 |              143 |               nan        |          nan        | False                     |
| stress                 | stress      | ood     | round_robin                   |            82.8436 |                   53.4089 |                    0 |              0         |                25 |              143 |               nan        |          nan        | False                     |
| stress                 | stress      | ood     | coolest_core_observed         |           130      |                   77.3781 |                   56 |              0.4       |                25 |              143 |               nan        |          nan        | True                      |
| stress                 | stress      | ood     | coolest_core_oracle_true_temp |            78.1651 |                   56.0858 |                    0 |              0         |                25 |              143 |               nan        |          nan        | False                     |
| stress                 | stress      | ood     | trend_aware_observed          |           130      |                   75.6387 |                   51 |              0.364286  |                25 |              143 |               nan        |          nan        | True                      |
| stress                 | stress      | ood     | point_prediction_rf           |            70.8114 |                   49.4497 |                    0 |              0         |                25 |              143 |               nan        |          nan        | False                     |
| stress                 | stress      | ood     | uncalibrated_quantile         |            97.0275 |                   58.3957 |                    7 |              0.05      |                25 |              143 |               nan        |          nan        | False                     |
| stress                 | stress      | ood     | conformal_upper_bound         |            77.0598 |                   50.1396 |                    0 |              0         |                25 |              143 |                 0.762238 |            0.770542 | False                     |



## Policy-Induced Distribution Drift

Scheduler-level drift summary:

| split   | scheduler                     |   drift_mean_abs_z |   drift_max_ks |
|:--------|:------------------------------|-------------------:|---------------:|
| id      | coolest_core_observed         |           1.16624  |       0.897227 |
| id      | trend_aware_observed          |           1.11266  |       0.836621 |
| id      | uncalibrated_quantile         |           0.56121  |       0.760563 |
| id      | conformal_upper_bound         |           0.259571 |       0.544632 |
| id      | random                        |           0.189316 |       0.446353 |
| id      | point_prediction_rf           |           0.151012 |       0.377389 |
| id      | coolest_core_oracle_true_temp |           0.138074 |       0.353535 |
| id      | round_robin                   |           0.134896 |       0.451961 |
| ood     | coolest_core_observed         |           3.58529  |       0.943396 |
| ood     | trend_aware_observed          |           3.33969  |       0.928721 |
| ood     | random                        |           1.46476  |       0.822393 |
| ood     | conformal_upper_bound         |           1.44231  |       0.84696  |
| ood     | round_robin                   |           1.44101  |       0.822393 |
| ood     | point_prediction_rf           |           1.42069  |       0.838574 |
| ood     | coolest_core_oracle_true_temp |           1.41841  |       0.822393 |
| ood     | uncalibrated_quantile         |           1.40127  |       0.844701 |

Largest feature-level shifts:

| split   | scheduler             | feature                |   calibration_mean |   visited_mean |   abs_mean_z_shift |   ks_stat |
|:--------|:----------------------|:-----------------------|-------------------:|---------------:|-------------------:|----------:|
| id      | coolest_core_observed | load_15                |           7.16901  |       57.3098  |            5.3011  |  0.617833 |
| id      | trend_aware_observed  | power_15               |           0.640258 |        4.22878 |            5.18876 |  0.83165  |
| id      | coolest_core_observed | power_15               |           0.640258 |        4.21846 |            5.17384 |  0.838384 |
| id      | trend_aware_observed  | load_15                |           7.16901  |       55.3838  |            5.09748 |  0.667259 |
| id      | coolest_core_observed | sensor_temp_imputed_15 |          37.3356   |       47.1285  |            4.58737 |  0.653946 |
| id      | trend_aware_observed  | sensor_temp_imputed_15 |          37.3356   |       46.3928  |            4.24277 |  0.664047 |
| id      | coolest_core_observed | sensor_temp_imputed_1  |          38.252    |       46.6089  |            3.00592 |  0.588917 |
| id      | coolest_core_observed | sensor_temp_imputed_2  |          38.252    |       46.6089  |            3.00592 |  0.588917 |
| id      | coolest_core_observed | sensor_temp_imputed_4  |          38.252    |       46.6089  |            3.00592 |  0.588917 |
| id      | coolest_core_observed | sensor_temp_imputed_5  |          38.252    |       46.6089  |            3.00592 |  0.588917 |
| id      | coolest_core_observed | sensor_temp_imputed_6  |          38.252    |       46.6089  |            3.00592 |  0.588917 |
| id      | coolest_core_observed | sensor_temp_imputed_7  |          38.252    |       46.6089  |            3.00592 |  0.588917 |
| id      | coolest_core_observed | sensor_temp_imputed_8  |          38.252    |       46.6089  |            3.00592 |  0.588917 |
| id      | coolest_core_observed | sensor_temp_imputed_9  |          38.252    |       46.6089  |            3.00592 |  0.588917 |
| id      | coolest_core_observed | sensor_temp_imputed_10 |          38.252    |       46.6089  |            3.00592 |  0.588917 |
| id      | coolest_core_observed | sensor_temp_imputed_11 |          38.252    |       46.6089  |            3.00592 |  0.588917 |
| id      | coolest_core_observed | sensor_temp_imputed_13 |          38.252    |       46.6089  |            3.00592 |  0.588917 |
| id      | coolest_core_observed | sensor_temp_imputed_14 |          38.252    |       46.6089  |            3.00592 |  0.588917 |
| id      | coolest_core_observed | mean_observed_temp     |          38.252    |       46.6089  |            3.00592 |  0.588917 |
| id      | trend_aware_observed  | sensor_temp_imputed_1  |          38.252    |       46.236   |            2.87179 |  0.588147 |

The drift table compares features visited by each scheduler's rollout against
the calibration feature distribution. This measures policy-induced state
distribution shift even when the workload generator remains in-distribution.

## Figures

Stable figure filenames under `outputs/figures/` (see the Visual Results
section below for plain-English explanations). Regenerate any time with
`python run_make_plots.py`.

- `outputs/figures/executive_summary.png` (portfolio/README overview)
- `outputs/figures/peak_temperature_by_scheduler_id.png`
- `outputs/figures/peak_temperature_by_scheduler_ood.png`
- `outputs/figures/hotspot_violations_id.png`
- `outputs/figures/hotspot_violations_ood.png`
- `outputs/figures/coverage_id_vs_ood.png`
- `outputs/figures/selected_core_coverage_gap.png`
- `outputs/figures/policy_drift_id_vs_ood.png`
- `outputs/figures/safety_vs_throughput_id.png`
- `outputs/figures/safety_vs_throughput_ood.png`
- `outputs/figures/heatmap_conformal_id.png`
- `outputs/figures/heatmap_conformal_ood.png`
- `outputs/figures/heatmap_comparison_ood.png`
- `outputs/figures/max_temperature_by_scheduler.png`

## Visual Results

The figures below turn the raw CSV metrics into the main result story for the
current quick run. All figures live under `outputs/figures/` with stable
filenames and can be regenerated independently with `python run_make_plots.py`.

![Executive summary](../figures/executive_summary.png)

The executive-summary figure is a single portfolio/README overview: OOD peak
temperature by scheduler, OOD hotspot violations, the conformal coverage
collapse from ID to OOD, and conformal policy drift. The detailed per-figure
breakdown follows.

![ID peak temperature by scheduler](../figures/peak_temperature_by_scheduler_id.png)

![OOD peak temperature by scheduler](../figures/peak_temperature_by_scheduler_ood.png)

Peak-temperature comparisons show the thermal safety margin against the 85 C
limit. In this quick run, several model-based schedulers avoid hotspots while
some sparse-observed baselines overheat badly under OOD conditions.

![ID hotspot violations](../figures/hotspot_violations_id.png)

![OOD hotspot violations](../figures/hotspot_violations_ood.png)

Hotspot bars make the safety failures more direct: ID is thermally easy here,
but OOD separates robust policies from brittle observed-sensor heuristics.

![Coverage ID vs OOD](../figures/coverage_id_vs_ood.png)

Conformal coverage is reported three ways: nominal target, marginal candidate
coverage, and selected-core coverage. ID selected coverage is near nominal; OOD
coverage collapses under OOD shift. This is why OOD calibration performance should not be
claimed as a formal safety guarantee.

![Selected-core coverage gap](../figures/selected_core_coverage_gap.png)

Selected-core coverage is measured separately because the scheduler chooses one
candidate out of 16. That selection step can create a gap from nominal coverage
even before considering policy-induced state drift.

![Policy drift ID vs OOD](../figures/policy_drift_id_vs_ood.png)

Policy drift compares rollout feature distributions against the calibration
feature distribution. It is a distinct effect from candidate selection bias and
from the deliberate OOD workload shift.

![ID safety vs throughput](../figures/safety_vs_throughput_id.png)

![OOD safety vs throughput](../figures/safety_vs_throughput_ood.png)

The safety/throughput scatter shows whether lower temperature is being bought
with lost completed work. In the current quick run, model-based schedulers avoid
hotspots without losing completed tasks, but harder presets are still needed if
ID remains too thermally easy.

![Conformal ID heatmap](../figures/heatmap_conformal_id.png)

![Conformal OOD heatmap](../figures/heatmap_conformal_ood.png)

![Conformal vs observed-baseline OOD heatmaps](../figures/heatmap_comparison_ood.png)

Representative 4x4 heatmaps show the final recorded chip-temperature frame for
the conformal scheduler. The OOD comparison heatmap puts the conformal scheduler
next to a bad observed-sensor baseline (`coolest_core_observed`), which chases
cool sensor readings into a hotspot under the OOD workload.

### What the figures say in plain English

- **ID calibration holds.** On in-distribution workloads, conformal
  selected-core coverage sits near the 0.9 nominal
  target.
- **OOD calibration breaks.** Under the shifted OOD workload, both marginal and
  selected coverage drop well below nominal, so the conformal guarantee should
  not be claimed as a formal OOD safety guarantee.
- **Selected-core coverage is measured separately** from marginal candidate
  coverage, because the scheduler picks one core out of 16 and that selection
  step can move coverage on its own.
- **Some observed-sensor baselines overheat badly in OOD.** Sparse-sensor
  heuristics such as coolest-core-observed and trend-aware-observed run far past
  the 85 C limit on OOD workloads.
- **Model-based schedulers avoid hotspots in this quick run**, staying under the
  thermal limit without losing completed tasks.
- **This quick run still needs harder presets.** ID is thermally easy here, so a
  more challenging preset is needed to validate that the model-based advantage is
  not just an artifact of an easy in-distribution regime.

## Limitations

This is a research MVP, not a validated chip thermal model. It does not include
HotSpot, OpenROAD, chiplets, DVFS, GNNs, active sensing, FPGA logic, production
hardware integration, or a production web application. The conformal guarantee
is marginal on calibration-like data and is not a formal OOD safety guarantee.
