# Multi-seed Evaluation (no retraining): normal

Workload seeds: 42, 17, 7, 11, 23

Models, conformal calibrator, and calibration feature statistics are held fixed
across seeds; only the simulator / workload-generation seed changes. Values are
mean +/- sample standard deviation across seeds. These are the headline numbers
for the writeup and resume.

| split   | scheduler                     | peak_temp (C)     | violations         | completed          | marginal_cov    | selected_cov    |
|:--------|:------------------------------|:------------------|:-------------------|:-------------------|:----------------|:----------------|
| id      | conformal_upper_bound         | 50.369 +/- 0.995  | 0.000 +/- 0.000    | 230.000 +/- 18.303 | 0.953 +/- 0.052 | 0.955 +/- 0.052 |
| id      | coolest_core_observed         | 68.312 +/- 3.513  | 0.000 +/- 0.000    | 230.000 +/- 18.303 |                 |                 |
| id      | coolest_core_oracle_true_temp | 52.713 +/- 3.260  | 0.000 +/- 0.000    | 230.000 +/- 18.303 |                 |                 |
| id      | point_prediction_rf           | 49.404 +/- 0.527  | 0.000 +/- 0.000    | 230.000 +/- 18.303 |                 |                 |
| id      | random                        | 57.464 +/- 4.526  | 0.000 +/- 0.000    | 230.000 +/- 18.303 |                 |                 |
| id      | round_robin                   | 53.866 +/- 2.763  | 0.000 +/- 0.000    | 230.000 +/- 18.303 |                 |                 |
| id      | trend_aware_observed          | 66.626 +/- 4.320  | 0.000 +/- 0.000    | 230.000 +/- 18.303 |                 |                 |
| id      | uncalibrated_quantile         | 59.200 +/- 2.299  | 0.000 +/- 0.000    | 230.000 +/- 18.303 |                 |                 |
| ood     | conformal_upper_bound         | 71.950 +/- 1.179  | 0.000 +/- 0.000    | 340.400 +/- 13.576 | 0.468 +/- 0.034 | 0.466 +/- 0.035 |
| ood     | coolest_core_observed         | 130.000 +/- 0.000 | 306.800 +/- 35.450 | 340.400 +/- 13.576 |                 |                 |
| ood     | coolest_core_oracle_true_temp | 83.499 +/- 4.381  | 6.600 +/- 13.667   | 340.400 +/- 13.576 |                 |                 |
| ood     | point_prediction_rf           | 83.664 +/- 13.499 | 8.600 +/- 13.557   | 340.400 +/- 13.576 |                 |                 |
| ood     | random                        | 99.386 +/- 10.374 | 51.600 +/- 30.664  | 340.400 +/- 13.576 |                 |                 |
| ood     | round_robin                   | 84.884 +/- 3.493  | 3.600 +/- 5.128    | 340.400 +/- 13.576 |                 |                 |
| ood     | trend_aware_observed          | 128.620 +/- 1.982 | 271.800 +/- 34.543 | 340.400 +/- 13.576 |                 |                 |
| ood     | uncalibrated_quantile         | 93.409 +/- 16.379 | 18.000 +/- 22.079  | 340.400 +/- 13.576 |                 |                 |
